import 'dart:typed_data';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_state_notifier/flutter_state_notifier.dart';
import 'package:instagram_clone/exceptions/custom_exception.dart';
import 'package:instagram_clone/providers/auth/auth_state.dart';
import 'package:instagram_clone/repositories/auth_repository.dart';
import 'package:state_notifier/state_notifier.dart';

class AuthProvider extends StateNotifier<AuthState> with LocatorMixin {
  AuthProvider() : super(AuthState.init());

  @override
  void update(Locator watch) {
    final user = watch<User?>();
    //회원가입시 메인화면 갔다가 로그인화면 페이지 이동 오류 수정
    if(user != null && !user.emailVerified){
      return;
    }
    if(user == null && state.authStatus == AuthStatus.unauthenticated){
      return;
    }

    if (user != null) {
      state = state.copyWith(
        authStatus: AuthStatus.authenticated,
      );
    }else {
      state = state.copyWith(
        authStatus: AuthStatus.unauthenticated,
      );
    }
  }

  Future<void> signOut() async {
    await read<AuthRepository>().signOut();

    /*state = state.copyWith(
      authStatus: AuthStatus.unauthenticated,
    );*/
  }

  /*
  signin(){
    //파이어베이스 로그인 작업
    state = state.copyWith(
      authStatus: AuthStatus.authenticated,
    );
  }*/

  Future<void> signUp({
    required String email,
    required String name,
    required String password,
    required Uint8List? profileImage,
  }) async {
    try {
      await read<AuthRepository>().signUp(
          email: email,
          name: name,
          password: password,
          profileImage: profileImage);
      //CustomException객체를 여기서 사용하지 않기 떄문에 catch(_)처리
    } on CustomException catch (_) {
      rethrow;
    }
  }

  Future<void> signIn({
    required String email,
    required String password,
  }) async {
    try {
      //repository의 signin을 호출
      await read<AuthRepository>().signIn(
        email: email,
        password: password,
      );
    } on CustomException catch (_) {
      rethrow;
    }
  }
}
